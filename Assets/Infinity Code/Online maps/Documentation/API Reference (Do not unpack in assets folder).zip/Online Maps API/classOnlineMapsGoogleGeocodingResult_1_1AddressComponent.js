var classOnlineMapsGoogleGeocodingResult_1_1AddressComponent =
[
    [ "long_name", "classOnlineMapsGoogleGeocodingResult_1_1AddressComponent.html#a77c88068292d988bb404bb28ffb6a151", null ],
    [ "short_name", "classOnlineMapsGoogleGeocodingResult_1_1AddressComponent.html#a4f1625f50334cbe353d51e986af1139d", null ],
    [ "types", "classOnlineMapsGoogleGeocodingResult_1_1AddressComponent.html#a959bb7f6b851c64205bb2d51909a14b7", null ]
];