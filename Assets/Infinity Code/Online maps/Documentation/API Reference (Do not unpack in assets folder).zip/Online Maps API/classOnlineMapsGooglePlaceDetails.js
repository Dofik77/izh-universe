var classOnlineMapsGooglePlaceDetails =
[
    [ "FindByPlaceID", "classOnlineMapsGooglePlaceDetails.html#a372fc11e600f9e17d1a441b9795d0c1d", null ],
    [ "GetResult", "classOnlineMapsGooglePlaceDetails.html#a61711b4007f61a3f3176ef0dcd6f84f4", null ]
];