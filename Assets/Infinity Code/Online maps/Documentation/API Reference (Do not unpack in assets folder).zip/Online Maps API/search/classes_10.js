var searchData=
[
  ['vehicle_1703',['Vehicle',['../classOnlineMapsGoogleDirectionsResult_1_1Vehicle.html',1,'OnlineMapsGoogleDirectionsResult']]],
  ['vehicletype_1704',['VehicleType',['../classOnlineMapsHereRoutingAPI_1_1VehicleType.html',1,'OnlineMapsHereRoutingAPI']]]
];
